Thank you for downloading the BETA version of "not a generic dusttrust game"

Accessing the game requires an activation code, you can roll for an activation code with the DinghyWorks bot in: https://discord.com/invite/tGuEqstf4r
(Read announcements for more information)

This build requires Python 3. An executable for the latest version (a supported version) of Python is included in the parent directory. To install Python, run the "python-3.13.0-amd64.exe" executable. An installation window will pop up prompting you to install the application.

MAKE SURE TO CHECK "Add python.exe to PATH." (Included in the screenshot.)

If the activation screen still fails despite owning Python,
1. Open a Command Prompt window
2. type "python"

If you get redirected to the Microsoft store or there is an error message about not recognizing Python as an external command, you do not have Python added to PATH.
There are many resources available on Youtube guiding you through on setting PATH.

By downloading and running this application you agree to the Terms of Service listed at: https://dingyspy.github.io/terms_of_service
In addition, you can find our privacy policy here: https://dingyspy.github.io/privacy_policy