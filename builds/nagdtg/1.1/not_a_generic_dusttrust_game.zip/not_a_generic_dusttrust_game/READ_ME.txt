Thank you for downloading the Beta version of "not a generic dusttrust game."

Accessing the game requires an activation code, currently there is no method of retrieving one. However, in the future, the steps to obtain an activation code will be found in my Discord server: https://discord.com/invite/tGuEqstf4r

This build requires Python 3. An executable for the latest version (a supported version) of Python is included in the parent directory. To install Python, run the "python-3.13.0-amd64.exe" executable. An installation window will pop up prompting you to install the application.

MAKE SURE TO CHECK "Add python.exe to PATH." (Included in the screenshot.)

By downloading and running this application you agree to the Terms of Service listed at: https://dingyspy.github.io/terms_of_service
In addition, you can find our privacy policy here: https://dingyspy.github.io/privacy_policy