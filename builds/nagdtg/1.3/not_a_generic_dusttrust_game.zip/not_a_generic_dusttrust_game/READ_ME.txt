Thank you for downloading the BETA version of "not a generic dusttrust game"

Accessing the game requires an activation code, you can roll for an activation code with the DinghyWorks bot in: https://discord.com/invite/tGuEqstf4r
(Read announcements for more information)

This build requires Python 3.

By downloading and running this application you agree to the Terms of Service listed at: https://dingyspy.github.io/terms_of_service
In addition, you can find our privacy policy here: https://dingyspy.github.io/privacy_policy







i had to conserve space to upload this update so like that's why there's no python executable
dw tho!! i think u guys already have it installed

-DiNgy